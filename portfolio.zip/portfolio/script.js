window.onload = function () {
    const homeLink = document.querySelector(".nav__links .home a");
    const aboutLink = document.querySelector(".nav__links .about a");
    const projectsLink = document.querySelector(".nav__links .projects a");
    const contactLink = document.querySelector(".nav__links .contact a");
    const hireBtn = document.querySelector(".btn.contact");
    const viewProjectsBtn = document.querySelector(".btn.projects");
    const contactMeBtn = document.querySelector(".btn.contact");
    const skillsLink = document.querySelector(".nav__links .skills a");
  
    const footerHomeLink = document.querySelector(".footer__col .home");
    const footerAboutLink = document.querySelector(".footer__col .about");
    const footerProjectsLink = document.querySelector(".footer__col .projects");
    const footerContactLink = document.querySelector(".footer__col .contact");
    const footerSkillsLink = document.querySelector(".footer__col .skills");
  
    function scrollToElement(elementId) {
      document.getElementById(elementId).scrollIntoView({
        behavior: "smooth",
      });
    }
  
    homeLink.addEventListener("click", (e) => {
      e.preventDefault();
      scrollToElement("home");
    });
  
    aboutLink.addEventListener("click", (e) => {
      e.preventDefault();
      scrollToElement("about");
    });
  
    projectsLink.addEventListener("click", (e) => {
      e.preventDefault();
      scrollToElement("projects");
    });
  
    contactLink.addEventListener("click", (e) => {
      e.preventDefault();
      scrollToElement("contact");
    });
  
    hireBtn.addEventListener("click", () => {
      scrollToElement("contact");
    });
  
    viewProjectsBtn.addEventListener("click", () => {
      scrollToElement("projects");
    });
  
    contactMeBtn.addEventListener("click", () => {
      scrollToElement("contact");
    });
  
    skillsLink.addEventListener("click", (e) => {
      e.preventDefault();
      scrollToElement("skills");
    });
  
    footerHomeLink.addEventListener("click", () => {
      scrollToElement("home");
    });
  
    footerAboutLink.addEventListener("click", () => {
      scrollToElement("about");
    });
  
    footerProjectsLink.addEventListener("click", () => {
      scrollToElement("projects");
    });
  
    footerContactLink.addEventListener("click", () => {
      scrollToElement("contact");
    });
  
    footerSkillsLink.addEventListener("click", () => {
      scrollToElement("skills");
    });
  };
  